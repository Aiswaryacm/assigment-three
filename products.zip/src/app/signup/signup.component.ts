import { Component, OnInit } from '@angular/core';
import {AuthService} from '../auth.service';
import { Router } from '@angular/router';
import {signupModel} from './signup.model';
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  title:String="SignUP";


  constructor(private authservice:AuthService,private router:Router) { }
  signupUserData= new signupModel(null,null,null,null);
  ngOnInit(): void {
  }
  signupUser(){
    console.log("signupcomponent"+this.signupUserData);
    this.authservice.signupUser(this.signupUserData)
    .subscribe(
      (data)=>{
        this.router.navigate(['/login']);
     })
    
    

  }
}
